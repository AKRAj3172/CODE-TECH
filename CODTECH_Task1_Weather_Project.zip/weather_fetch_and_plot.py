import matplotlib.pyplot as plt

# Mock weather data
CITY = "Delhi"
data = {
    "temp": 33,
    "feels_like": 36,
    "humidity": 45,
    "pressure": 1008,
    "description": "scattered clouds"
}

print(f"Weather in {CITY}")
print(f"Temperature: {data['temp']} °C")
print(f"Feels Like: {data['feels_like']} °C")
print(f"Humidity: {data['humidity']}%")
print(f"Pressure: {data['pressure']} hPa")
print(f"Condition: {data['description']}")

# Visualization
labels = ['Temperature', 'Feels Like', 'Humidity', 'Pressure']
values = [data['temp'], data['feels_like'], data['humidity'], data['pressure']]

plt.figure(figsize=(8, 5))
plt.bar(labels, values, color=['orange', 'red', 'blue', 'green'])
plt.title(f"Weather Metrics for {CITY}")
plt.ylabel("Values")
plt.grid(axis='y')
plt.tight_layout()
plt.savefig("weather_chart.png")
plt.show()
