import pandas as pd
from fpdf import FPDF

# Load data
df = pd.read_csv("data.csv")
summary = df.describe()

# Create PDF report
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(200, 10, txt="Student Marks Report", ln=True, align='C')
pdf.ln(10)

for col in summary.columns:
    pdf.cell(200, 10, txt=f"Column: {col}", ln=True)
    for stat in summary.index:
        pdf.cell(200, 10, txt=f"{stat}: {summary[col][stat]:.2f}", ln=True)
    pdf.ln()

pdf.output("report.pdf")
print("PDF report generated successfully.")
