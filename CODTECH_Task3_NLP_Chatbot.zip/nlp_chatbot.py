from nltk.chat.util import Chat, reflections

# Define pairs for chatbot
pairs = [
    [r"hi|hello", ["Hello!", "Hi there!"]],
    [r"what is your name?", ["I am a simple chatbot."]],
    [r"how are you?", ["I'm good, thank you!"]],
    [r"what can you do?", ["I can answer simple questions."]],
    [r"bye", ["Goodbye!", "See you later!"]]
]

# Create and start chat
chatbot = Chat(pairs, reflections)
chatbot.converse()
