# Task 4: Spam Detection Model

This task implements a simple spam detection model using the Naive Bayes classifier and text vectorization.

##  Objective
Classify messages as `spam` or `ham` using a machine learning model trained on a labeled dataset.

##  Tools & Libraries
- `pandas`
- `scikit-learn`
- `CountVectorizer`
- `MultinomialNB`

##  Files Included
- `spam_detector_model.ipynb` — Jupyter Notebook implementing the full pipeline.
- `spam.csv` — Sample dataset with example `spam` and `ham` messages.

##  How It Works
1. **Data Loading**: Reads `spam.csv`, a CSV with labeled messages.
2. **Preprocessing**: Converts text into numerical vectors using `CountVectorizer`.
3. **Model Training**: Trains a Naive Bayes classifier using `MultinomialNB`.
4. **Evaluation**: Evaluates the model on a test set and prints accuracy.

##  Run Instructions
1. Open the notebook in Jupyter or Google Colab.
2. Run all cells to train and evaluate the model.
3. View the final accuracy score.

##  Sample Output
```
Accuracy: 1.0
```

*Note: This is a very small dataset. Real accuracy may vary with larger datasets.*
